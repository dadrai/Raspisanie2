<!DOCTYPE html>
<html>

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">


<link href='fcln/lib/main.css' rel='stylesheet' />
<script src='fcln/lib/main.js'></script>


<style>


    body {
        font-family: Arial, Helvetica Neue, Helvetica, sans-serif;
        padding: 0px;
        background:white;
    }


    .header {
        padding: 30px;
        font-size: 40px;
        text-align: center;
        background: white;
    }





    .card {
        background-color: white;
        padding: 50px 200px;

    }





    .icon-bar {
        width: 100%;
        background-color: #0f1226;
        overflow: auto;
    }


    .icon-bar a {
        float: right;
        width: 15%;
        text-align: center;
        padding: 20px 0;
        transition: all 0.3s ease;
        color: white;
        font-size: 20px;
        text-decoration: none;
    }


    .icon-bar a:hover {
        background-color: #171d54;
    }

    .active {
        background-color: #171d54;
    }

    .tab {

        overflow: hidden;
        border: 1px solid #ccc;
        background-color: #f1f1f1;
    }

    /* Style the buttons inside the tab */
    .tab button {
        background-color: inherit;
        float: center;
        border: none;
        outline: none;
        cursor: pointer;
        padding: 14px 16px;
        transition: 0.3s;
        font-size: 17px;
    }

    /* Change background color of buttons on hover */
    .tab button:hover {
        background-color: #171d54;
        color: white;
    }

    /* Create an active/current tablink class */
    .tab button.active {
        background-color: #171d54;
        color: white;
    }

    /* Style the tab content */
    .tabcontent {
        display: none;
        padding: 6px 12px;
        border: 1px solid #ccc;
        border-top: none;
    }

    .table-striped > tbody > tr:nth-child(2n+1) > td, .table-striped > tbody > tr:nth-child(2n+1) > th {
        background-color: #ebecf5;
    }

    .column {
        float: left;
        padding: 30px;
        height: auto; /* Should be removed. Only for demonstration */
    }

    .left {
        width: 45%;
    }

    .right {
        width: 55%;
    }

    /* Clear floats after the columns */
    .row:after {
        content: "";
        display: table;
        clear: both;
    }


    /* Style inputs */
    input[type=text], select, textarea {
        width: 100%;
        padding: 12px;
        border: 1px solid #ccc;
        margin-top: 6px;
        margin-bottom: 16px;
        resize: vertical;
    }

    input[type=submit] {
        background-color: #4CAF50;
        color: white;
        padding: 12px 20px;
        border: none;
        cursor: pointer;
    }

    input[type=submit]:hover {
        background-color: #45a049;
    }

    /* Style the container/contact section */
    .container {
        border-radius: 5px;
        background-color: #f2f2f2;
        padding: 10px;
    }


    #calendar {
        max-width: 700px;
        margin: 0 auto;
    }


</style>
<head>

    <div class="icon-bar">

        <a <?php echo $__env->yieldContent('a5'); ?> href="<?php echo e(route('vhod')); ?>">Вход</a>
        <a <?php echo $__env->yieldContent('a4'); ?> href="<?php echo e(route('kon')); ?>">Контакты</a>
        <a <?php echo $__env->yieldContent('a3'); ?> href="<?php echo e(route('ay')); ?>">Расписание Аудиторий</a>
        <a <?php echo $__env->yieldContent('a2'); ?> href="<?php echo e(route('pr')); ?>">Расписание Преподователей</a>
        <a <?php echo $__env->yieldContent('a1'); ?> href="<?php echo e(route('gr')); ?>">Расписание Групп</a>
        <a style=" float: left" href="https://www.tspu.edu.ru/"><img src="https://eios.tspu.edu.ru/static/img/logos/logo.png" width="50"
                                                                     height="30"  alt=""></a>

    </div>

</head>
<body>


<div class="card">

<?php echo $__env->yieldContent('select1'); ?>

</div>

<div class="card">

<?php echo $__env->yieldContent('table'); ?>


</div>



</body>
</html>
<?php /**PATH C:\xampp\htdocs\timetable\resources\views/shablontimetable.blade.php ENDPATH**/ ?>