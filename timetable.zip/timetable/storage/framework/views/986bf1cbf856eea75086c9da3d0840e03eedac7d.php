<script>

    document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');

        var calendar = new FullCalendar.Calendar(calendarEl, {
            headerToolbar: {
                left: 'prevYear,prev,next,nextYear today',
                center: 'title',
                right: 'dayGridMonth,dayGridWeek,dayGridDay'
            },
            initialDate: '2020-09-12',
            navLinks: true, // can click day/week names to navigate views
            editable: true,
            dayMaxEvents: true, // allow "more" link when too many events
            events: [
                {
                    title: 'All Day Event',
                    start: '2020-09-01'
                },
                {
                    title: 'Long Event',
                    start: '2020-09-07',
                    end: '2020-09-10'
                },
                {
                    groupId: 999,
                    title: 'Repeating Event',
                    start: '2020-09-09T16:00:00'
                },
                {
                    groupId: 999,
                    title: 'Repeating Event',
                    start: '2020-09-16T16:00:00'
                },
                {
                    title: 'Conference',
                    start: '2020-09-11',
                    end: '2020-09-13'
                },
                {
                    title: 'Meeting',
                    start: '2020-09-12T10:30:00',
                    end: '2020-09-12T12:30:00'
                },
                {
                    title: 'Lunch',
                    start: '2020-09-12T12:00:00'
                },
                {
                    title: 'Meeting',
                    start: '2020-09-12T14:30:00'
                },
                {
                    title: 'Happy Hour',
                    start: '2020-09-12T17:30:00'
                },
                {
                    title: 'Dinner',
                    start: '2020-09-12T20:00:00'
                },
                {
                    title: 'Birthday Party',
                    start: '2020-09-13T07:00:00'
                },
                {
                    title: 'Click for Google',
                    url: 'http://google.com/',
                    start: '2020-09-28'
                }
            ]
        });

        calendar.render();
    });

</script>
<style>





</style>

<?php $__env->startSection('a1'); ?>
    class="active"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('select1'); ?>
    <input list="ShowDataList" class="form-control" placeholder="Выберите номер группы:">

    <datalist id="ShowDataList">
        <option value=491>
        <option value="492">
        <option value="493">
        <option value="3811111">
    </datalist>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('table'); ?>




    <div id='calendar'></div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('raspisanie'); ?>
    <div  id = "Pon"  class="tabcontent">

        <table class="table table-bordered table-striped">
            <thead>
            <tr>
                <th style="width: 10%" scope="col">Время</th>
                <th style= "text-align: center" scope="col">Предмет</th>

            </tr>
            </thead>

            <tbody>
            <tr>
                <th scope="row">8:30 - 10:05</th>
                <td>
                    <p>Ауд. 23</p>
                    <p>Иванов А.Д.</p>
                    <p>Информатика</p>
                </td>


            </tr>
            <tr>
                <th scope="row">10:20 - 11:55</th>
                <td>
                    <p>Ауд. 35</p>
                    <p>Котов Б.А.</p>
                    <p>Информационные системы</p>
                </td>

            </tr>
            <tr>
                <th scope="row">12:25 - 14:00</th>
                <td><p>Ауд. 11</p>
                    <p>Руднов К.А.</p>
                    <p>Программирование</p></td>

            </tr>
            <tr>
                <th scope="row">14:15 - 15:50</th>
                <td> </td>

            </tr>
            <tr>
                <th scope="row">16:05 - 17:40</th>
                <td> </td>

            </tr>
            </tbody>
        </table>

    </div>

    <div id="Vt" class="tabcontent">

        <table class="table table-bordered table-striped">
            <thead>
            <tr>
                <th style="width: 10%" scope="col">Время</th>
                <th style= "text-align: center" scope="col">Предмет</th>

            </tr>
            </thead>
            <tbody>
            <tr>
                <th scope="row">8:30 - 10:05</th>
                <td>
                </td>


            </tr>
            <tr>
                <th scope="row">10:20 - 11:55</th>
                <td>
                    <p>Ауд. 35</p>
                    <p>Петров Д.Б.</p>
                    <p>Математика</p>
                </td>

            </tr>
            <tr>
                <th scope="row">12:25 - 14:00</th>
                <td><p>Ауд. 11</p>
                    <p>Коломатов О.Д.</p>
                    <p>Программирование</p></td>

            </tr>
            <tr>
                <th scope="row">14:15 - 15:50</th>
                <td> </td>

            </tr>
            <tr>
                <th scope="row">16:05 - 17:40</th>
                <td> </td>

            </tr>

            </tbody>
    </div>

    </table>

    </div>

    <div id="Sr" class="tabcontent">

        <table class="table table-bordered table-striped">
            <thead>
            <tr>
                <th style="width: 10%" scope="col">Время</th>
                <th style= "text-align: center" scope="col">Предмет</th>

            </tr>
            </thead>
            <tbody>

            <tr>
                <th scope="row">8:30 - 10:05</th>
                <td> </td>
            </tr>
            <tr>
                <th scope="row">10:20 - 11:55</th>
                <td>
                </td>

            </tr>
            <tr>
                <th scope="row">12:25 - 14:00</th>
                <td> </td>

            </tr>
            <tr>
                <th scope="row">14:15 - 15:50</th>
                <td> </td>

            </tr>
            <tr>
                <th scope="row">16:05 - 17:40</th>
                <td> </td>

            </tr>
            </tbody>
    </div>

    </table>

    </div>

    <div id="Cht" class="tabcontent">

        <table class="table table-bordered table-striped">
            <thead>
            <tr>
                <th style="width: 10%" scope="col">Время</th>
                <th style= "text-align: center" scope="col">Предмет</th>

            </tr>
            </thead>
            <tbody>

            <tr>
                <th scope="row">8:30 - 10:05</th>
                <td> </td>
            </tr>
            <tr>
                <th scope="row">10:20 - 11:55</th>
                <td>
                </td>

            </tr>
            <tr>
                <th scope="row">12:25 - 14:00</th>
                <td> </td>

            </tr>
            <tr>
                <th scope="row">14:15 - 15:50</th>
                <td> </td>

            </tr>
            <tr>
                <th scope="row">16:05 - 17:40</th>
                <td> </td>

            </tr>
            </tbody>
    </div>

    </table>

    </div>

    <div id="Pt" class="tabcontent">

        <table class="table table-bordered table-striped">
            <thead>
            <tr>
                <th style="width: 10%" scope="col">Время</th>
                <th style= "text-align: center" scope="col">Предмет</th>

            </tr>
            </thead>
            <tbody>

            <tr>
                <th scope="row">8:30 - 10:05</th>
                <td> </td>
            </tr>
            <tr>
                <th scope="row">10:20 - 11:55</th>
                <td>
                </td>

            </tr>
            <tr>
                <th scope="row">12:25 - 14:00</th>
                <td> </td>

            </tr>
            <tr>
                <th scope="row">14:15 - 15:50</th>
                <td> </td>

            </tr>
            <tr>
                <th scope="row">16:05 - 17:40</th>
                <td> </td>

            </tr>
            </tbody>
    </div>

    </table>

    </div>

    <div id="Sb" class="tabcontent">
        <table class="table table-bordered table-striped">
            <thead>
            <tr>
                <th style="width: 10%" scope="col">Время</th>
                <th style= "text-align: center" scope="col">Предмет</th>

            </tr>
            </thead>
            <tbody>

            <tr>
                <th scope="row">8:30 - 10:05</th>
                <td> </td>
            </tr>
            <tr>
                <th scope="row">10:20 - 11:55</th>
                <td>
                </td>

            </tr>
            <tr>
                <th scope="row">12:25 - 14:00</th>
                <td> </td>

            </tr>
            <tr>
                <th scope="row">14:15 - 15:50</th>
                <td> </td>

            </tr>
            <tr>
                <th scope="row">16:05 - 17:40</th>
                <td> </td>

            </tr>
            </tbody>
    </div>

    </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('table1'); ?>

        <div class="tab">


            <button class="tablinks" onclick="openDen(event, 'Pon')"><h3>Понедельник</h3></button>
            <button class="tablinks" onclick="openDen(event, 'Vt')"><h3>Вторник</h3></button>
            <button class="tablinks" onclick="openDen(event, 'Sr')"><h3>Среда</h3></button>
            <button class="tablinks" onclick="openDen(event, 'Cht')"><h3>Четверг</h3></button>
            <button class="tablinks" onclick="openDen(event, 'Pt')"><h3>Пятница</h3></button>
            <button class="tablinks" onclick="openDen(event, 'Sb')"><h3>Суббота</h3></button>
        </div>

        <?php echo $__env->yieldContent('raspisanie'); ?>






    <script>
        function openDen(evt, cityName) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tabcontent");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }
            tablinks = document.getElementsByClassName("tablinks");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
            }
            document.getElementById(cityName).style.display = "block";
            evt.currentTarget.className += " active";
        }
    </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('shablontimetable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\timetable\resources\views/group.blade.php ENDPATH**/ ?>